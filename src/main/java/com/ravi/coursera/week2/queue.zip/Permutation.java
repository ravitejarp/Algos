
import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args) {
        String input = StdIn.readString();
        int temp = Integer.parseInt(args[0]);
        RandomizedQueue<String> rand = new RandomizedQueue<>();
        while (input != null) {
            rand.enqueue(input);
            input = StdIn.readString();
        }
        while (temp > 0) {
            temp--;
            System.out.println(rand.dequeue());

        }

    }
}